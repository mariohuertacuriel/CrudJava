
package modelo;


import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ClientesDAO {
    
    Connection conexion;
    
    public ClientesDAO () {
        Conexion con = new Conexion();
        conexion=con.getConexion();
}
    public List<Clientes> listarClientes(){
        PreparedStatement ps;
        ResultSet rs;
        List<Clientes> lista = new ArrayList<>();
        try {
            ps= conexion.prepareStatement("SELECT id, nombre, direccion, edad, telefono FROM clientes");
            rs=ps.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                int edad = rs.getInt("edad");
                int telefono = rs.getInt("telefono");
                Clientes cliente = new Clientes(id, nombre, direccion, edad, telefono);
                lista.add(cliente);
            }
            return lista;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return null;
        }
    }
 
    public Clientes mostrarCliente(int _id){
        PreparedStatement ps;
        ResultSet rs;
        Clientes cliente = null;
        try {
            ps= conexion.prepareStatement("SELECT id, nombre, direccion, edad, telefono FROM clientes WHERE id=?");
            ps.setInt(1, _id);
            rs=ps.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                int edad = rs.getInt("edad");
                int telefono = rs.getInt("telefono");
                cliente = new Clientes(id, nombre, direccion, edad, telefono);
               
            }
            return cliente;
        } catch (SQLException e) {
            System.out.println(e.toString());
            return null;
        }
    }
    
    public  boolean insertar(Clientes cliente){
        PreparedStatement ps;
        try {
            ps= conexion.prepareStatement("INSERT INTO clientes(nombre, direccion, edad, telefono) VALUES (?,?,?,?)");
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getDireccion());
            ps.setInt(3, cliente.getEdad());
            ps.setInt(4, cliente.getTelefono());
            ps.execute();
            return true;
      
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
    
     public  boolean actualizar(Clientes cliente){
        PreparedStatement ps;
        try {
            ps= conexion.prepareStatement("UPDATE clientes SET nombre=?, direccion=?, edad=?, telefono=? WHERE id=?");
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getDireccion());
            ps.setInt(3, cliente.getEdad());
            ps.setInt(4, cliente.getTelefono());
            ps.setInt(5, cliente.getId());
            ps.execute();
            return true;
      
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
     
     public  boolean eliminar(int _id){
        PreparedStatement ps;
        try {
            ps= conexion.prepareStatement("DELETE FROM clientes WHERE id=?");
            ps.setInt(1, _id);
            ps.execute();
            return true;
      
        } catch (SQLException e) {
            System.out.println(e.toString());
            return false;
        }
    }
       
}

