
package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import utilerias.ClassConex;


public class DaoUsuario extends ClassConex{
    private Connection conn=null;
    private Statement st= null;
    private ResultSet rs=null; 
    
    public DaoUsuario(){
        super();
    }
    public boolean validar(String nom, String clave){
        boolean encontrado= false;
    
        try {
            conn=this.obtenerConexion();
            st=conn.createStatement();
            rs=st.executeQuery("select * from vendedores where nombre='"+nom+"'and password='"+clave+"';");
          
            if (rs.next()){ 
                encontrado=true;
        }
        this.cerrarConexion();
        }catch (Exception e){          
        }
        return encontrado; 
}
}